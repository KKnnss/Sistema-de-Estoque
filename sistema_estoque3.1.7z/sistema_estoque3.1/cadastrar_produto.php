<?php
require 'config.php';
 

$codigo = filter_input(INPUT_GET, 'codigo');
$nome = filter_input(INPUT_GET, 'nome');
$preco = filter_input(INPUT_GET, 'preco');
$quantidade = filter_input(INPUT_GET, 'quantidade');
$quantidade_min = filter_input(INPUT_GET, 'quantidade_min');
//$img = filter_input(INPUT_GET, 'avatar');


    
    if($codigo && $nome && $preco && $quantidade && $quantidade_min){
        
        $sql = $pdo->prepare("INSERT INTO produtos (codigo,nome,preco,quantidade,quantidade_min) VALUES (:codigo, :nome, :preco, :quantidade, :quantidade_min)");
        $sql->bindValue(":codigo", $codigo);
        $sql->bindValue(":nome", $nome);
        $sql->bindValue(":preco", $preco);
        $sql->bindValue(":quantidade", $quantidade);
        $sql->bindValue(":quantidade_min", $quantidade_min);
        
        $sql->execute();
        
        header("Location:home.php");
        exit;
    }
        else {
            //header('Location: cadastrar_produto.php');
            // exit;
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./static/style_home.css">
    <link rel="stylesheet" href="./static/style_cadastroP.css">
</head>
<body>

<div class="container">

<header>       
    <a href="home.php">Home</a>
    <a href="cadastrar_produto.php">Cadastrar Produtos</a>
    
    <a href="relatorio.php" >Relatorio</a>
</header>



</div>



    <div class="formulario">

    
    <form action="" method="get" enctype="multipart/form-data">
        <div>
            <label for="codigo">Codigo:</br>
            <input  class="inp"type="text" name="codigo">
            </label>
        </div>
        <div>
            <label for="">Nome:</br>
            <input type="text" name="nome">
            </label>
        </div>
        <div>
            <label for="">Preço:</br></br>
            <input class="inp" type="text" name="preco">
            </label>
        </div>
        <div>
            <label for="">Quantidade: </br>
            <input  class="inp"type="text" name="quantidade">
            </label>
        </div>
        <div>
            <label for="">Quantidade est: <br/>
            <input class="inp" type="text" name="quantidade_min">
            </label>
        </div>
        
        <div>
            <input type="submit" class="botao" name="enviar">
        </div>
            

    </form>
</div>

</body>
</html>
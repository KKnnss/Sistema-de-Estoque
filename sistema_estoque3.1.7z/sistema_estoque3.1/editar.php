
<?php


require 'config.php';

   
    $id = filter_input(INPUT_GET, 'id');
    $codigo = filter_input(INPUT_GET, 'codigo'); 
    $nome = filter_input(INPUT_GET, 'nome'); 
    $preco = filter_input(INPUT_GET, 'preco'); 
    $quantidade = filter_input(INPUT_GET, 'quantidade'); 
    $quantidade_min = filter_input(INPUT_GET, 'quantidade_min'); 
    
   
    
    $listas = [];


    if($id) {

        $sql = $pdo->query("SELECT * FROM produtos WHERE id = $id");

        $listas = $sql->fetch(PDO::FETCH_ASSOC);  

    }






    
    if($id && $codigo && $nome && $preco && $quantidade && $quantidade_min) {
        

        $sql = $pdo->prepare("UPDATE produtos SET codigo = :codigo, nome = :nome, preco = :preco, quantidade = :quantidade, quantidade_min = :quantidade_min WHERE id = :id");
        $sql->bindValue(':codigo',"$codigo"); 
        $sql->bindValue(':nome',$nome);
        $sql->bindValue(':preco',$preco);
        $sql->bindValue(':quantidade',$quantidade);
        $sql->bindValue(':quantidade_min',$quantidade_min);
        $sql->bindValue(':id',$id); 
        $sql->execute(); 
    
        // header("Location: lista_produtos.php");
        // exit;

    } else {
         
        //  header('Location: editar.php'); 
        //  exit;
    }    


    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./static/style_cadastroP.css">
</head>
<body>

 <div class="formulario">

    <form action="" method="get">

   <input type="hidden" name="id" value="<?=$listas['id']?>">
    
    <div>
            <label for="codigo">Codigo:</br>
            <input type="text" name="codigo" value="<?=$listas['codigo']?>">
            </label>
        </div>
        <div>
            <label for="">Nome:</br>
            <input type="text" name="nome" value="<?=$listas['nome']?>">
            </label>
        </div>
        <div>
            <label for="">Preço:</br></br>
            <input type="text" name="preco" value="<?=$listas['preco']?>">
            </label>
        </div>
        <div>
            <label for="">Quantidade: </br>
            <input type="text" name="quantidade" value="<?=$listas['quantidade']?>">
            </label>
        </div>
        <div>
            <label for="">Quantidade est: <br/>
            <input type="text" name="quantidade_min" value="<?=$listas['quantidade_min']?>">
            </label>
        </div>

        <div>
            <input type="submit" class="botao" name="enviar">
        </div>
            
    </form>

  <form action="recebedor.php" method="post" enctype="multipart/form-data" />
  <input type="hidden" name="id" value="<?=$listas['id']?>">
  
            <input type="file" name="arquivo" />
            <input type="submit" value="Enviar">
        </form>

        

 </div>




    
</body>
</html>